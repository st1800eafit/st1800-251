from pyflink.datastream import StreamExecutionEnvironment
from pyflink.common.serialization import SimpleStringSchema
from pyflink.datastream.connectors import FlinkKinesisConsumer
import json
from pyflink.common.typeinfo import Types

def create_kinesis_source(stream_name, region):
    properties = {
        'aws.region': region,
        'stream.initial.position': 'LATEST'
    }
    return FlinkKinesisConsumer(
        stream_name,
        SimpleStringSchema(),
        properties
    )

def main():
    env = StreamExecutionEnvironment.get_execution_environment()
    env.set_parallelism(1)

    # Define source
    kinesis_source = create_kinesis_source('input-stream', 'us-east-1')
    stream = env.add_source(kinesis_source).map(lambda x: x, output_type=Types.STRING())

    # Simple transformation: split line into words
    words = stream.flat_map(
        lambda line: line.split(" "),
        output_type=Types.STRING()
    )

    # Print to logs (or define a sink here)
    words.map(lambda word: f"word: {word}", output_type=Types.STRING()).print()

    env.execute("PyFlink Kinesis Word Count")

if __name__ == '__main__':
    main()
